import { i as __toESM } from "../_runtime.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { B as notFound, V as require_react, _ as createFileRoute, b as useRouter, d as HeadContent, f as useRouterState, g as lazyRouteComponent, h as Outlet, l as require_react_dom, m as createRouter, u as Scripts, v as createRootRoute, x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as TriangleAlert } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/analisis-XtM0KeeS.js
var ANALISIS = [
	{
		slug: "xauusd-22-mei-2024",
		pair: "XAU/USD",
		date: "22 Mei 2024",
		title: "XAUUSD Analysis 22 Mei 2024",
		excerpt: "Potensi kenaikan menuju area resistance utama.",
		icon: "trendUp",
		accent: "blue",
		body: [
			"Harga emas (XAUUSD) melanjutkan momentum bullish setelah berhasil bertahan di atas area support kunci pada kisaran 2.380.",
			"Selama harga bertahan di atas level tersebut, peluang kenaikan lanjutan menuju area resistance berikutnya masih terbuka.",
			"Perhatikan reaksi harga saat mendekati zona resistance, karena berpotensi terjadi koreksi jangka pendek sebelum melanjutkan tren utama."
		]
	},
	{
		slug: "btcusd-22-mei-2024",
		pair: "BTC/USD",
		date: "22 Mei 2024",
		title: "BTCUSD Analysis 22 Mei 2024",
		excerpt: "Struktur market masih bullish selama tidak break support.",
		icon: "bitcoin",
		accent: "orange",
		body: [
			"Bitcoin masih bergerak dalam struktur higher-low yang menandakan tren naik jangka menengah masih berlaku.",
			"Selama harga tidak menembus ke bawah area support utama, bias tetap condong ke sisi bullish.",
			"Volume yang meningkat saat kenaikan menjadi konfirmasi tambahan minat beli masih cukup kuat."
		]
	},
	{
		slug: "eurusd-21-mei-2024",
		pair: "EUR/USD",
		date: "21 Mei 2024",
		title: "EURUSD Analysis 21 Mei 2024",
		excerpt: "Peluang reversal jika menembus area support.",
		icon: "euro",
		accent: "green",
		body: [
			"EURUSD bergerak mendekati area support jangka pendek setelah mengalami tekanan jual beberapa hari terakhir.",
			"Apabila area ini berhasil ditembus dengan momentum yang kuat, peluang reversal ke bawah semakin terbuka.",
			"Sebaliknya, penolakan di area ini bisa membawa harga kembali menguji resistance terdekat."
		]
	},
	{
		slug: "xauusd-20-mei-2024",
		pair: "XAU/USD",
		date: "20 Mei 2024",
		title: "XAUUSD Analysis 20 Mei 2024",
		excerpt: "Konsolidasi jelang rilis data inflasi AS.",
		icon: "trendUp",
		accent: "blue",
		body: [
			"Emas bergerak sideways dalam range yang cukup sempit menjelang rilis data inflasi Amerika Serikat.",
			"Pelaku pasar tampak menahan posisi besar sambil menunggu arah baru pasca rilis data.",
			"Breakout dari range konsolidasi ini berpotensi menentukan arah pergerakan jangka pendek."
		]
	},
	{
		slug: "gbpusd-19-mei-2024",
		pair: "GBP/USD",
		date: "19 Mei 2024",
		title: "GBPUSD Analysis 19 Mei 2024",
		excerpt: "Tekanan jual masih mendominasi pergerakan jangka pendek.",
		icon: "trendDown",
		accent: "red",
		body: [
			"GBPUSD masih tertekan dan bergerak dalam struktur lower-high pada timeframe H4.",
			"Selama belum ada penembusan ke atas resistance terdekat, bias jangka pendek masih bearish.",
			"Level support di bawah perlu diwaspadai sebagai area potensi pantulan teknikal."
		]
	},
	{
		slug: "btcusd-18-mei-2024",
		pair: "BTC/USD",
		date: "18 Mei 2024",
		title: "BTCUSD Analysis 18 Mei 2024",
		excerpt: "Menguji area resistance psikologis penting.",
		icon: "bitcoin",
		accent: "orange",
		body: [
			"Bitcoin mendekati level resistance psikologis yang selama ini menjadi acuan banyak pelaku pasar.",
			"Penembusan yang disertai volume tinggi bisa membuka ruang kenaikan lanjutan.",
			"Namun, penolakan di area ini berpotensi memicu koreksi jangka pendek terlebih dahulu."
		]
	}
];
function getAnalisis(slug) {
	return ANALISIS.find((item) => item.slug === slug);
}
function getAnalisisPairs() {
	return [...new Set(ANALISIS.map((item) => item.pair))];
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/utils-C_uf36nf.js
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/edukasi-CNf4cXmh.js
var EDUKASI = [
	{
		slug: "pip-lot-leverage",
		level: "Pemula",
		title: "Apa itu Pip, Lot, dan Leverage?",
		desc: "Pahami istilah dasar yang wajib diketahui sebelum mulai trading forex maupun emas.",
		body: [
			"Pip adalah satuan perubahan harga terkecil di pasar forex, biasanya berada di digit keempat di belakang koma (contoh: EURUSD bergerak dari 1.0850 ke 1.0851 berarti naik 1 pip). Khusus pasangan yang melibatkan Yen Jepang, pip berada di digit kedua karena konvensi penulisan harganya berbeda.",
			"Lot adalah satuan volume transaksi. Satu standard lot setara 100.000 unit mata uang dasar, mini lot 10.000 unit, dan micro lot 1.000 unit. Semakin besar lot yang dipakai, semakin besar pula nilai pergerakan setiap pip terhadap saldo akun.",
			"Leverage adalah fasilitas dari broker yang memungkinkan trader membuka posisi jauh lebih besar dari modal yang disetorkan, misalnya dengan rasio 1:100 atau 1:500. Leverage memperbesar potensi profit, tapi juga memperbesar potensi kerugian dengan proporsi yang sama — sehingga pemahaman manajemen risiko wajib dikuasai sebelum menggunakannya."
		]
	},
	{
		slug: "cara-membaca-candlestick",
		level: "Pemula",
		title: "Cara Membaca Candlestick",
		desc: "Kenali pola candlestick dasar untuk membaca sentimen pasar secara visual.",
		body: [
			"Satu candlestick menggambarkan pergerakan harga dalam satu periode waktu tertentu, terdiri dari body (selisih harga open dan close) serta wick atau sumbu (harga tertinggi dan terendah selama periode itu). Candle hijau/putih biasanya menandakan harga close lebih tinggi dari open (bullish), sedangkan candle merah/hitam menandakan sebaliknya (bearish).",
			"Beberapa pola satu candle yang sering diperhatikan trader antara lain doji (body sangat kecil, tanda keraguan pasar), hammer (wick bawah panjang setelah tren turun, tanda potensi pembalikan), dan candle engulfing (candle besar yang menelan candle sebelumnya, tanda perubahan momentum).",
			"Pola candlestick paling berguna bila dibaca bersama konteks lain, seperti posisinya terhadap area support/resistance atau tren di timeframe yang lebih besar — bukan sebagai sinyal berdiri sendiri."
		]
	},
	{
		slug: "support-resistance-dalam-praktik",
		level: "Menengah",
		title: "Support & Resistance dalam Praktik",
		desc: "Teknik menentukan area kunci yang sering jadi acuan pantulan maupun breakout harga.",
		body: [
			"Support adalah area harga di mana tekanan beli cenderung cukup kuat untuk menahan penurunan lebih lanjut, sementara resistance adalah area di mana tekanan jual cenderung menahan kenaikan. Level ini terbentuk dari titik-titik harga yang berulang kali menjadi tempat pembalikan di masa lalu.",
			"Cara praktis menentukannya: tarik garis atau zona pada beberapa swing high/low yang saling berdekatan, bukan satu garis tunggal yang terlalu presisi. Semakin sering suatu area disentuh dan direspons harga, semakin banyak pelaku pasar yang menganggapnya signifikan.",
			"Saat harga menembus (breakout) area tersebut, sering terjadi retest — harga kembali mendekati level yang baru saja ditembus sebelum melanjutkan arah breakout. Trader juga perlu waspada terhadap false breakout, yaitu penembusan yang gagal berlanjut dan harga kembali ke dalam rentang sebelumnya."
		]
	},
	{
		slug: "manajemen-risiko-lot-size",
		level: "Menengah",
		title: "Manajemen Risiko: Menentukan Lot Size",
		desc: "Cara menghitung ukuran posisi berdasarkan modal dan toleransi risiko.",
		body: [
			"Konsep dasar manajemen risiko adalah membatasi kerugian per transaksi pada persentase kecil dari total modal — banyak trader menggunakan acuan umum di kisaran 1–2% per posisi, meski angka ini bersifat pilihan pribadi, bukan aturan baku.",
			"Ukuran lot yang tepat bisa dihitung dari tiga hal: nilai modal, persentase risiko yang ditetapkan, dan jarak stop loss dalam pip. Semakin jauh jarak stop loss, semakin kecil lot yang digunakan agar nilai risiko dalam rupiah/dolar tetap konsisten.",
			"Manajemen risiko yang konsisten membantu trader bertahan menghadapi rangkaian kerugian (drawdown) tanpa menghabiskan modal secara signifikan. Ini bersifat kerangka berpikir umum, bukan rekomendasi angka spesifik untuk akun siapa pun — sesuaikan dengan toleransi risiko dan kondisi modal masing-masing."
		]
	},
	{
		slug: "korelasi-xauusd-dxy",
		level: "Lanjutan",
		title: "Memahami Korelasi XAUUSD dan DXY",
		desc: "Kenapa pergerakan emas sering berlawanan arah dengan indeks dolar AS.",
		body: [
			"DXY (US Dollar Index) mengukur kekuatan dolar AS terhadap sekeranjang mata uang utama dunia. Karena harga emas (XAUUSD) dikuotasi dalam dolar, pelemahan dolar membuat emas relatif lebih murah bagi pemegang mata uang lain, yang berpotensi mendorong permintaan dan harga emas naik — begitu pula sebaliknya.",
			"Hubungan ini dikenal sebagai korelasi negatif, tetapi sifatnya kecenderungan umum, bukan hukum pasti yang berlaku setiap saat. Ada periode di mana korelasi ini melemah atau bahkan berbalik untuk sementara.",
			"Salah satu contohnya adalah saat krisis atau ketidakpastian global memuncak: dolar dan emas bisa sama-sama dicari sebagai aset safe haven, sehingga keduanya menguat bersamaan. Karena itu, DXY sebaiknya dijadikan salah satu konteks pendukung, bukan satu-satunya acuan analisis XAUUSD."
		]
	},
	{
		slug: "trading-berdasarkan-kalender-ekonomi",
		level: "Lanjutan",
		title: "Trading Berdasarkan Kalender Ekonomi",
		desc: "Strategi menghadapi volatilitas tinggi saat rilis data ekonomi penting.",
		body: [
			"Kalender ekonomi mencatat jadwal rilis data dan kebijakan penting — seperti data inflasi, ketenagakerjaan, atau keputusan suku bunga bank sentral — yang berpotensi memicu pergerakan harga signifikan dalam waktu singkat.",
			"Tiga angka yang biasa ditampilkan adalah forecast (perkiraan konsensus pasar), previous (data periode sebelumnya), dan actual (angka yang benar-benar dirilis). Semakin jauh selisih actual dari forecast, semakin besar potensi reaksi pasar, terutama untuk data dengan level dampak tinggi.",
			"Karena pergerakan harga di sekitar rilis data berdampak tinggi bisa sangat cepat dan tidak terduga (termasuk risiko slippage dan spread melebar), banyak trader memilih memperlebar stop loss, mengurangi ukuran posisi, atau menghindari membuka posisi baru tepat menjelang rilis data tersebut."
		]
	}
];
function getEdukasi(slug) {
	return EDUKASI.find((item) => item.slug === slug);
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/news-BXDftyj_.js
var NEWS = [
	{
		slug: "fed-pertahankan-suku-bunga",
		date: "22 Mei 2024",
		category: "Ekonomi Global",
		thumb: "capitol",
		title: "The Fed Pertahankan Suku Bunga, Pasar Menunggu Data Inflasi",
		excerpt: "Bank sentral Amerika Serikat memutuskan mempertahankan suku bunga acuan, sembari pasar menanti rilis data inflasi berikutnya sebagai penentu arah kebijakan.",
		body: [
			"The Federal Reserve memutuskan untuk mempertahankan suku bunga acuan pada level saat ini, sesuai dengan ekspektasi mayoritas pelaku pasar.",
			"Dalam pernyataannya, bank sentral menekankan bahwa keputusan ke depan akan sangat bergantung pada perkembangan data inflasi dan tenaga kerja.",
			"Pasar keuangan global merespons dengan volatilitas terbatas, sembari menunggu rilis data inflasi berikutnya sebagai indikator arah kebijakan suku bunga selanjutnya."
		]
	},
	{
		slug: "emas-menguat-ketidakpastian-global",
		date: "22 Mei 2024",
		category: "Emas",
		thumb: "gold",
		title: "Emas Menguat di Tengah Ketidakpastian Global",
		excerpt: "Harga emas mencatat penguatan seiring meningkatnya permintaan aset safe haven di tengah ketidakpastian ekonomi dan geopolitik global.",
		body: [
			"Harga emas dunia bergerak menguat, didorong oleh meningkatnya minat investor terhadap aset safe haven.",
			"Ketidakpastian geopolitik serta ekspektasi kebijakan moneter yang beragam turut menjadi faktor pendukung penguatan harga emas.",
			"Analis menilai tren ini berpotensi berlanjut selama sentimen ketidakpastian global masih membayangi pasar."
		]
	},
	{
		slug: "etf-bitcoin-inflow-tertinggi",
		date: "21 Mei 2024",
		category: "Kripto",
		thumb: "bitcoin",
		title: "ETF Bitcoin Spot Catat Inflow Tertinggi dalam 2 Minggu",
		excerpt: "Produk ETF Bitcoin spot mencatatkan arus masuk dana tertinggi dalam dua minggu terakhir, menandakan minat institusi yang kembali meningkat.",
		body: [
			"Sejumlah produk ETF Bitcoin spot mencatatkan arus masuk dana (inflow) tertinggi dalam dua minggu terakhir.",
			"Peningkatan ini mengindikasikan minat investor institusi terhadap aset kripto kembali menguat.",
			"Para pelaku pasar akan memantau apakah tren inflow ini dapat berlanjut dan memberi dampak positif terhadap harga Bitcoin secara keseluruhan."
		]
	},
	{
		slug: "data-tenaga-kerja-as",
		date: "19 Mei 2024",
		category: "Ekonomi Global",
		thumb: "capitol",
		title: "Data Tenaga Kerja AS Jadi Sorotan Pelaku Pasar Minggu Ini",
		excerpt: "Rilis data tenaga kerja Amerika Serikat pekan ini diperkirakan akan menjadi katalis penting bagi pergerakan dolar dan pasar global.",
		body: [
			"Pelaku pasar tengah menantikan rilis data tenaga kerja Amerika Serikat yang dijadwalkan pekan ini.",
			"Data ini berpotensi memberikan gambaran lebih jelas mengenai kondisi ekonomi AS dan arah kebijakan moneter ke depan.",
			"Pergerakan dolar AS dan pasar global diperkirakan akan cukup sensitif terhadap hasil rilis data tersebut."
		]
	}
];
function getNews(slug) {
	return NEWS.find((item) => item.slug === slug);
}
function getNewsCategories() {
	return [...new Set(NEWS.map((item) => item.category))];
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-BoayDiKZ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var import_react_dom = require_react_dom();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: error.message || "An unexpected error occurred. Try reloading the page."
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	if (typeof window === "undefined") return () => {};
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	const parentOrigin = resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		if (envelope.data.type === "hello") {
			if (!HelloSchema.safeParse(event.data).success) return;
			announce();
			return;
		}
		if (envelope.data.type === "navigate") {
			const parsed = NavigateSchema.safeParse(event.data);
			if (!parsed.success) return;
			navigate(parsed.data.path);
			queueMicrotask(reportLocation);
			return;
		}
		if (envelope.data.type === "history") {
			const parsed = HistorySchema.safeParse(event.data);
			if (!parsed.success) return;
			if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
			window.history.go(parsed.data.delta);
		}
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
/**
* Official-style Birustock mark: three stacked parallelograms forming a
* geometric B — cyan top bar, mid blue bar, navy triangle — with a soft shadow.
*/
function BrandMark({ className }) {
	const uid = (0, import_react.useId)().replace(/:/g, "");
	const top = `gTop-${uid}`;
	const mid = `gMid-${uid}`;
	const bot = `gBot-${uid}`;
	const shadow = `sh-${uid}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		className: cn("brand-mark", className),
		viewBox: "0 0 68 86",
		xmlns: "http://www.w3.org/2000/svg",
		"aria-hidden": "true",
		focusable: "false",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("defs", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
					id: top,
					x1: "0",
					y1: "0",
					x2: "1",
					y2: "1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
						offset: "0",
						stopColor: "#5AC8FA"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
						offset: "1",
						stopColor: "#1A7CFF"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
					id: mid,
					x1: "0",
					y1: "0",
					x2: "1",
					y2: "1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
						offset: "0",
						stopColor: "#2B7BFF"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
						offset: "1",
						stopColor: "#0D4FD8"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
					id: bot,
					x1: "0",
					y1: "0",
					x2: "1",
					y2: "1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
						offset: "0",
						stopColor: "#1A5FE8"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
						offset: "1",
						stopColor: "#0836B8"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("filter", {
					id: shadow,
					x: "-25%",
					y: "-12%",
					width: "160%",
					height: "150%",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("feDropShadow", {
						dx: "1",
						dy: "1.6",
						stdDeviation: "1.2",
						floodColor: "#0A3A90",
						floodOpacity: "0.28"
					})
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				filter: `url(#${shadow})`,
				fill: `url(#${top})`,
				d: "M7 36 L14 12 L60 6 L53 30 Z"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				filter: `url(#${shadow})`,
				fill: `url(#${mid})`,
				d: "M7 58 L13 38 L52 32 L46 52 Z"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				filter: `url(#${shadow})`,
				fill: `url(#${bot})`,
				d: "M7 80 L13 60 L40 54 L24 80 Z"
			})
		]
	});
}
function BrandLockup({ size = "md", className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: cn("brand-lockup", size === "lg" && "brand-lockup-lg", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrandMark, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "brand-divider",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "brand-wordmark",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "brand-name",
					children: "Birustock"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "brand-sub",
					children: "Indonesia"
				})]
			})
		]
	});
}
var FOOTER_LINKS = [
	{
		to: "/analisis",
		label: "Analisis"
	},
	{
		to: "/news",
		label: "News"
	},
	{
		to: "/edukasi",
		label: "Edukasi"
	},
	{
		to: "/kontak",
		label: "Kontak"
	},
	{
		to: "/kalender-ekonomi",
		label: "Kalender Ekonomi"
	},
	{
		to: "/profil",
		label: "Profil"
	}
];
function SiteFooter() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
		className: "border-t border-line pt-12 pb-7",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container-site",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-8 pb-8 md:grid-cols-[1.2fr_1fr_1.4fr]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						"aria-label": "Birustock Indonesia — Beranda",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrandLockup, {})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3.5 text-[13px] text-subtle",
						children: [
							"© ",
							(/* @__PURE__ */ new Date()).getFullYear(),
							" Birustock ID. All rights reserved."
						]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h5", {
						className: "mb-3.5 text-xs font-bold tracking-[0.08em] text-subtle",
						children: "LINK CEPAT"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 gap-x-6 gap-y-2.5",
						children: FOOTER_LINKS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: item.to,
							className: "text-sm text-muted transition-colors hover:text-primary",
							children: item.label
						}, item.to))
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h5", {
						className: "mb-3.5 text-xs font-bold tracking-[0.08em] text-subtle",
						children: "DISCLAIMER"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[13px] leading-relaxed text-muted",
						children: "Konten ini hanya bersifat informatif dan tidak dimaksudkan sebagai saran atau rekomendasi investasi. Trading memiliki risiko kerugian."
					})] })
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "border-t border-line pt-5 text-[13px] text-subtle",
				children: "Birustock Indonesia — Analisis. Edukasi. Insight."
			})]
		})
	});
}
function IconTikTok({ size = 20, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		width: size,
		height: size,
		viewBox: "0 0 24 24",
		fill: "currentColor",
		"aria-hidden": "true",
		className,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M16.5 2h-3v13.2a2.8 2.8 0 1 1-2-2.68V9.4a5.8 5.8 0 1 0 5 5.75V9.1a7.4 7.4 0 0 0 4.5 1.53v-3a4.4 4.4 0 0 1-4.5-4.4V2z" })
	});
}
function IconTelegram({ size = 20, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		width: size,
		height: size,
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "1.8",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": "true",
		className,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M21 4 3 11.2l6 2.1M21 4 14.8 20l-5.8-6.7M21 4 9 13.3" })
	});
}
function IconInstagram({ size = 20, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		width: size,
		height: size,
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "1.8",
		"aria-hidden": "true",
		className,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "3",
				y: "3",
				width: "18",
				height: "18",
				rx: "5"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "12",
				cy: "12",
				r: "4"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "17.2",
				cy: "6.8",
				r: "1.1",
				fill: "currentColor",
				stroke: "none"
			})
		]
	});
}
function IconSearch({ size = 20, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		width: size,
		height: size,
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "1.8",
		strokeLinecap: "round",
		"aria-hidden": "true",
		className,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "10.5",
			cy: "10.5",
			r: "6.5"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
			x1: "21",
			y1: "21",
			x2: "15.5",
			y2: "15.5"
		})]
	});
}
function IconArrowRight({ size = 16, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		width: size,
		height: size,
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "2",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": "true",
		className,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
			x1: "4",
			y1: "12",
			x2: "19",
			y2: "12"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", { points: "13 6 19 12 13 18" })]
	});
}
function IconTrendUp({ size = 20, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		width: size,
		height: size,
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "2",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": "true",
		className,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", { points: "3 17 10 10 14 14 21 6" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", { points: "15 6 21 6 21 12" })]
	});
}
function IconTrendDown({ size = 20, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		width: size,
		height: size,
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "2",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": "true",
		className,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", { points: "3 7 10 14 14 10 21 18" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", { points: "15 18 21 18 21 12" })]
	});
}
function IconBitcoin({ size = 20, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		width: size,
		height: size,
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "1.8",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": "true",
		className,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "12",
			cy: "12",
			r: "9"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M9.8 7.5h3.4a2 2 0 0 1 0 4H9.8m0 0h3.8a2 2 0 0 1 0 4H9.8m0-8v9m1.6-9v9.5m2-9.5v9.5" })]
	});
}
function IconEuro({ size = 20, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		width: size,
		height: size,
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "1.8",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": "true",
		className,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "12",
			cy: "12",
			r: "9"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M15 8.3a4.6 4.6 0 1 0 0 7.4M7.5 10.5h6M7.5 13.2h5" })]
	});
}
function IconDocument({ size = 20, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		width: size,
		height: size,
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "1.8",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": "true",
		className,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M6 2.5h8l4 4V21a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V3.5a1 1 0 0 1 1-1z" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M14 2.5V7h4" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
				x1: "8",
				y1: "12",
				x2: "16",
				y2: "12"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
				x1: "8",
				y1: "15.5",
				x2: "16",
				y2: "15.5"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
				x1: "8",
				y1: "19",
				x2: "13",
				y2: "19"
			})
		]
	});
}
function IconGraduation({ size = 20, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		width: size,
		height: size,
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "1.8",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": "true",
		className,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M2.5 9 12 4.5 21.5 9 12 13.5 2.5 9z" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M6.5 11v4.5c0 1.4 2.5 3 5.5 3s5.5-1.6 5.5-3V11" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M21.5 9v6" })
		]
	});
}
function IconCalendar({ size = 20, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		width: size,
		height: size,
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "1.8",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": "true",
		className,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "3",
				y: "5",
				width: "18",
				height: "16",
				rx: "2"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
				x1: "3",
				y1: "10",
				x2: "21",
				y2: "10"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
				x1: "8",
				y1: "2.5",
				x2: "8",
				y2: "6.5"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
				x1: "16",
				y1: "2.5",
				x2: "16",
				y2: "6.5"
			})
		]
	});
}
function CandlestickPattern() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 580 120",
		xmlns: "http://www.w3.org/2000/svg",
		preserveAspectRatio: "xMidYMid meet",
		"aria-hidden": "true",
		children: [
			22,
			34,
			18,
			40,
			28,
			46,
			30,
			52,
			24,
			38,
			44,
			20,
			32,
			48,
			26,
			36
		].map((h, i) => {
			const x = 20 + i * 34;
			const wickTop = 60 - h / 2 - 14;
			const wickBottom = 60 + h / 2 + 14;
			const y = 60 - h / 2;
			const fill = i % 3 !== 0 ? "#2563eb" : "#c7d2e8";
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
				x1: x + 6,
				y1: wickTop,
				x2: x + 6,
				y2: wickBottom,
				stroke: fill,
				strokeWidth: "1.5"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x,
				y,
				width: "12",
				height: h,
				fill,
				rx: "1.5"
			})] }, i);
		})
	});
}
function NewsThumb({ type }) {
	if (type === "capitol") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 64 64",
		width: "100%",
		height: "100%",
		preserveAspectRatio: "xMidYMid slice",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				width: "64",
				height: "64",
				fill: "#1e2a4a"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "32",
				cy: "20",
				r: "7",
				fill: "#d7dee8"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "29",
				y: "12",
				width: "6",
				height: "6",
				fill: "#d7dee8"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
				points: "14,30 32,20 50,30",
				fill: "#c3ccdb"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "16",
				y: "30",
				width: "4",
				height: "18",
				fill: "#c3ccdb"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "24",
				y: "30",
				width: "4",
				height: "18",
				fill: "#c3ccdb"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "32",
				y: "30",
				width: "4",
				height: "18",
				fill: "#c3ccdb"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "40",
				y: "30",
				width: "4",
				height: "18",
				fill: "#c3ccdb"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "12",
				y: "48",
				width: "40",
				height: "5",
				fill: "#c3ccdb"
			})
		]
	});
	if (type === "gold") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 64 64",
		width: "100%",
		height: "100%",
		preserveAspectRatio: "xMidYMid slice",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
				id: "goldGrad",
				x1: "0",
				y1: "0",
				x2: "1",
				y2: "1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
					offset: "0",
					stopColor: "#f6d778"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
					offset: "1",
					stopColor: "#c8952f"
				})]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				width: "64",
				height: "64",
				fill: "#2b2118"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("g", {
				transform: "translate(8,36)",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
					points: "0,10 6,0 42,0 48,10 42,18 6,18",
					fill: "url(#goldGrad)",
					stroke: "#8a6416",
					strokeWidth: "1"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("g", {
				transform: "translate(12,20)",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
					points: "0,10 5,2 37,2 42,10 37,16 5,16",
					fill: "url(#goldGrad)",
					stroke: "#8a6416",
					strokeWidth: "1"
				})
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 64 64",
		width: "100%",
		height: "100%",
		preserveAspectRatio: "xMidYMid slice",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				width: "64",
				height: "64",
				fill: "#1b1607"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "32",
				cy: "32",
				r: "18",
				fill: "#f7931a"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: "32",
				y: "39",
				fontFamily: "Arial, sans-serif",
				fontSize: "22",
				fontWeight: "700",
				fill: "#1b1607",
				textAnchor: "middle",
				children: "B"
			})
		]
	});
}
var SOCIAL_ICONS = {
	tiktok: IconTikTok,
	telegram: IconTelegram,
	instagram: IconInstagram
};
function SocialIcon({ id, size = 20 }) {
	const Icon = SOCIAL_ICONS[id];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { size });
}
var PAIR_ICONS = {
	trendUp: IconTrendUp,
	trendDown: IconTrendDown,
	bitcoin: IconBitcoin,
	euro: IconEuro
};
function PairIcon({ id, size = 20 }) {
	const Icon = PAIR_ICONS[id];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { size });
}
var NAV_ITEMS = [
	{
		to: "/",
		label: "Beranda"
	},
	{
		to: "/analisis",
		label: "Analisis"
	},
	{
		to: "/news",
		label: "News"
	},
	{
		to: "/edukasi",
		label: "Edukasi"
	},
	{
		to: "/kalender-ekonomi",
		label: "Kalender Ekonomi"
	},
	{
		to: "/profil",
		label: "Profil"
	},
	{
		to: "/kontak",
		label: "Kontak"
	}
];
var SOCIAL_LINKS = [
	{
		href: "https://www.tiktok.com/@birustock.id",
		label: "TikTok",
		id: "tiktok"
	},
	{
		href: "https://t.me/birustockid",
		label: "Telegram",
		id: "telegram"
	},
	{
		href: "https://www.instagram.com/birustock.id",
		label: "Instagram",
		id: "instagram"
	}
];
function isNavActive(pathname, href) {
	if (href === "/") return pathname === "/";
	return pathname === href || pathname.startsWith(`${href}/`);
}
function SiteHeader() {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const [open, setOpen] = (0, import_react.useState)(false);
	const [mounted, setMounted] = (0, import_react.useState)(false);
	const toggleRef = (0, import_react.useRef)(null);
	const drawerRef = (0, import_react.useRef)(null);
	const menuId = (0, import_react.useId)();
	(0, import_react.useEffect)(() => {
		setMounted(true);
	}, []);
	(0, import_react.useEffect)(() => {
		setOpen(false);
	}, [pathname]);
	(0, import_react.useEffect)(() => {
		const body = document.body;
		if (open) {
			const scrollbar = window.innerWidth - document.documentElement.clientWidth;
			body.classList.add("nav-locked");
			if (scrollbar > 0) body.style.paddingRight = `${scrollbar}px`;
		} else {
			body.classList.remove("nav-locked");
			body.style.paddingRight = "";
		}
		return () => {
			body.classList.remove("nav-locked");
			body.style.paddingRight = "";
		};
	}, [open]);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const drawer = drawerRef.current;
		if (!drawer) return;
		const focusable = () => Array.from(drawer.querySelectorAll("a[href], button:not([disabled])")).filter((el) => !el.hasAttribute("disabled"));
		(focusable()[0] ?? toggleRef.current)?.focus();
		const onKey = (e) => {
			if (e.key === "Escape") {
				e.preventDefault();
				setOpen(false);
				toggleRef.current?.focus();
				return;
			}
			if (e.key !== "Tab") return;
			const list = focusable();
			if (list.length === 0) return;
			const first = list[0];
			const last = list[list.length - 1];
			if (e.shiftKey && document.activeElement === first) {
				e.preventDefault();
				last.focus();
			} else if (!e.shiftKey && document.activeElement === last) {
				e.preventDefault();
				first.focus();
			}
		};
		document.addEventListener("keydown", onKey);
		return () => document.removeEventListener("keydown", onKey);
	}, [open]);
	const closeMenu = () => {
		setOpen(false);
		toggleRef.current?.focus();
	};
	const menu = mounted ? (0, import_react_dom.createPortal)(/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("mobile-overlay", open && "is-open"),
		onClick: closeMenu,
		"aria-hidden": "true"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: drawerRef,
		id: menuId,
		className: cn("mobile-drawer", open && "is-open"),
		role: "dialog",
		"aria-modal": "true",
		"aria-label": "Menu navigasi",
		inert: !open,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			className: "mobile-nav",
			"aria-label": "Navigasi seluler",
			children: NAV_ITEMS.map((item) => {
				const active = isNavActive(pathname, item.to);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: item.to,
					className: "mobile-nav-link",
					"aria-current": active ? "page" : void 0,
					onClick: () => setOpen(false),
					children: item.label
				}, item.to);
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mobile-drawer-foot",
			children: SOCIAL_LINKS.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: s.href,
				target: "_blank",
				rel: "noopener noreferrer",
				className: "mobile-social",
				"aria-label": s.label,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SocialIcon, {
					id: s.id,
					size: 20
				})
			}, s.id))
		})]
	})] }), document.body) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
		className: "site-header",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container-site header-inner",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "shrink-0",
					"aria-label": "Birustock Indonesia — Beranda",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrandLockup, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "desktop-nav",
					"aria-label": "Navigasi utama",
					children: NAV_ITEMS.map((item) => {
						const active = isNavActive(pathname, item.to);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: item.to,
							className: "nav-link",
							"aria-current": active ? "page" : void 0,
							children: item.label
						}, item.to);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "header-actions",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "header-social",
							children: SOCIAL_LINKS.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: s.href,
								target: "_blank",
								rel: "noopener noreferrer",
								className: "header-icon-btn",
								"aria-label": s.label,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SocialIcon, {
									id: s.id,
									size: 18
								})
							}, s.id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/news",
							className: "header-icon-btn",
							"aria-label": "Cari berita",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconSearch, { size: 18 })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							ref: toggleRef,
							type: "button",
							className: "nav-toggle",
							"aria-expanded": open,
							"aria-controls": menuId,
							"aria-label": open ? "Tutup menu" : "Buka menu",
							onClick: () => setOpen((v) => !v),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "nav-toggle-box",
								"aria-hidden": "true",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "nav-toggle-line" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "nav-toggle-line" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "nav-toggle-line" })
								]
							})
						})
					]
				})
			]
		})
	}), menu] });
}
function SiteShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col bg-bg text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "flex-1",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
function NotFoundPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "py-16",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container-site py-16 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 mb-3 text-4xl font-extrabold tracking-tight text-ink",
					children: "Halaman tidak ditemukan"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-6 text-muted",
					children: "Halaman yang kamu cari tidak tersedia atau sudah dipindahkan."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "btn btn-primary",
					children: "Kembali ke Beranda"
				})
			]
		})
	});
}
var styles_default = "/assets/styles-Bk7DT5A_.css";
var APP_NAME = "Birustock Indonesia";
var Route$10 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "description",
				content: "Analisis teknikal, berita pasar, dan edukasi trading Crypto, Forex, dan Gold oleh Birustock Indonesia."
			},
			{
				name: "theme-color",
				content: "#1656E8"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:ital,wght@0,400;0,500;0,600;0,700;0,800;1,400&display=swap"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	notFoundComponent: NotFoundPage,
	component: RootDocument
});
function RootDocument() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "id",
		className: "antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	});
}
var $$splitComponentImporter$9 = () => import("./routes-CX7yIk8y.mjs");
var Route$9 = createFileRoute("/")({
	component: lazyRouteComponent($$splitComponentImporter$9, "component"),
	head: () => ({ meta: [{ title: "Beranda | Birustock Indonesia" }, {
		name: "description",
		content: "Insight pasar, keputusan lebih baik. Analisis teknikal, berita, dan edukasi trading Crypto, Forex, dan Gold."
	}] })
});
var $$splitComponentImporter$8 = () => import("./analisis-CtZ7F2rW.mjs");
var Route$8 = createFileRoute("/analisis")({
	component: lazyRouteComponent($$splitComponentImporter$8, "component"),
	head: () => ({ meta: [{ title: "Analisis Terbaru | Birustock Indonesia" }] })
});
var $$splitComponentImporter$7 = () => import("./edukasi-BgJui_QT.mjs");
var Route$7 = createFileRoute("/edukasi")({
	component: lazyRouteComponent($$splitComponentImporter$7, "component"),
	head: () => ({ meta: [{ title: "Edukasi Trading | Birustock Indonesia" }] })
});
var $$splitComponentImporter$6 = () => import("./kalender-ekonomi-DMf9sJYx.mjs");
var Route$6 = createFileRoute("/kalender-ekonomi")({
	component: lazyRouteComponent($$splitComponentImporter$6, "component"),
	head: () => ({ meta: [{ title: "Kalender Ekonomi | Birustock Indonesia" }] })
});
var $$splitComponentImporter$5 = () => import("./kontak-BHmIhmit.mjs");
var Route$5 = createFileRoute("/kontak")({
	component: lazyRouteComponent($$splitComponentImporter$5, "component"),
	head: () => ({ meta: [{ title: "Kontak | Birustock Indonesia" }] })
});
var $$splitComponentImporter$4 = () => import("./news-DK1MFOu0.mjs");
var Route$4 = createFileRoute("/news")({
	component: lazyRouteComponent($$splitComponentImporter$4, "component"),
	head: () => ({ meta: [{ title: "News Terbaru | Birustock Indonesia" }] })
});
var $$splitComponentImporter$3 = () => import("./profil-DbHhEpVI.mjs");
var Route$3 = createFileRoute("/profil")({
	component: lazyRouteComponent($$splitComponentImporter$3, "component"),
	head: () => ({ meta: [{ title: "Profil | Birustock Indonesia" }] })
});
var $$splitComponentImporter$2 = () => import("./analisis._slug-CiA-R50K.mjs");
var Route$2 = createFileRoute("/analisis/$slug")({
	loader: ({ params }) => {
		const item = getAnalisis(params.slug);
		if (!item) throw notFound();
		return item;
	},
	component: lazyRouteComponent($$splitComponentImporter$2, "component"),
	head: ({ loaderData }) => ({ meta: [{ title: `${loaderData?.title ?? "Analisis"} | Birustock Indonesia` }, {
		name: "description",
		content: loaderData?.excerpt ?? ""
	}] })
});
var $$splitComponentImporter$1 = () => import("./edukasi._slug-DPgeolxW.mjs");
var Route$1 = createFileRoute("/edukasi/$slug")({
	loader: ({ params }) => {
		const item = getEdukasi(params.slug);
		if (!item) throw notFound();
		return item;
	},
	component: lazyRouteComponent($$splitComponentImporter$1, "component"),
	head: ({ loaderData }) => ({ meta: [{ title: `${loaderData?.title ?? "Edukasi"} | Birustock Indonesia` }, {
		name: "description",
		content: loaderData?.desc ?? ""
	}] })
});
var $$splitComponentImporter = () => import("./news._slug-D_YJHhzJ.mjs");
var Route = createFileRoute("/news/$slug")({
	loader: ({ params }) => {
		const item = getNews(params.slug);
		if (!item) throw notFound();
		return item;
	},
	component: lazyRouteComponent($$splitComponentImporter, "component"),
	head: ({ loaderData }) => ({ meta: [{ title: `${loaderData?.title ?? "News"} | Birustock Indonesia` }, {
		name: "description",
		content: loaderData?.excerpt ?? ""
	}] })
});
var IndexRoute = Route$9.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$10
});
var AnalisisRoute = Route$8.update({
	id: "/analisis",
	path: "/analisis",
	getParentRoute: () => Route$10
});
var EdukasiRoute = Route$7.update({
	id: "/edukasi",
	path: "/edukasi",
	getParentRoute: () => Route$10
});
var KalenderEkonomiRoute = Route$6.update({
	id: "/kalender-ekonomi",
	path: "/kalender-ekonomi",
	getParentRoute: () => Route$10
});
var KontakRoute = Route$5.update({
	id: "/kontak",
	path: "/kontak",
	getParentRoute: () => Route$10
});
var NewsRoute = Route$4.update({
	id: "/news",
	path: "/news",
	getParentRoute: () => Route$10
});
var ProfilRoute = Route$3.update({
	id: "/profil",
	path: "/profil",
	getParentRoute: () => Route$10
});
var AnalisisSlugRoute = Route$2.update({
	id: "/$slug",
	path: "/$slug",
	getParentRoute: () => AnalisisRoute
});
var EdukasiSlugRoute = Route$1.update({
	id: "/$slug",
	path: "/$slug",
	getParentRoute: () => EdukasiRoute
});
var NewsSlugRoute = Route.update({
	id: "/$slug",
	path: "/$slug",
	getParentRoute: () => NewsRoute
});
var AnalisisRouteChildren = { AnalisisSlugRoute };
var AnalisisRouteWithChildren = AnalisisRoute._addFileChildren(AnalisisRouteChildren);
var EdukasiRouteChildren = { EdukasiSlugRoute };
var EdukasiRouteWithChildren = EdukasiRoute._addFileChildren(EdukasiRouteChildren);
var NewsRouteChildren = { NewsSlugRoute };
var rootRouteChildren = {
	IndexRoute,
	AnalisisRoute: AnalisisRouteWithChildren,
	EdukasiRoute: EdukasiRouteWithChildren,
	KalenderEkonomiRoute,
	KontakRoute,
	NewsRoute: NewsRoute._addFileChildren(NewsRouteChildren),
	ProfilRoute
};
var routeTree = Route$10._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent,
		defaultPreload: "intent",
		scrollRestoration: true
	});
}
//#endregion
export { getAnalisisPairs as S, NEWS as _, CandlestickPattern as a, cn as b, IconDocument as c, IconTelegram as d, IconTikTok as f, BrandLockup as g, PairIcon as h, Route$2 as i, IconGraduation as l, NewsThumb as m, Route as n, IconArrowRight as o, IconTrendUp as p, Route$1 as r, IconCalendar as s, router_exports as t, IconInstagram as u, getNewsCategories as v, ANALISIS as x, EDUKASI as y };
