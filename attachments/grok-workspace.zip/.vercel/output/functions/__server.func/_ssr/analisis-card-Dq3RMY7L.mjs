import { x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { b as cn, h as PairIcon, o as IconArrowRight } from "./router-BoayDiKZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/analisis-card-Dq3RMY7L.js
var import_jsx_runtime = require_jsx_runtime();
var ACCENT = {
	blue: "",
	orange: "badge-orange",
	green: "badge-green",
	red: "badge-red"
};
var TILE = {
	blue: "",
	orange: "icon-tile-orange",
	green: "icon-tile-green",
	red: "icon-tile-red"
};
function AnalisisCard({ item }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "card",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: cn("badge", ACCENT[item.accent]),
					children: item.pair
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-[13px] text-subtle",
					children: item.date
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-[17px] leading-snug font-bold text-ink",
					children: item.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: item.excerpt
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: cn("icon-tile", TILE[item.accent]),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PairIcon, { id: item.icon })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/analisis/$slug",
				params: { slug: item.slug },
				className: "link-arrow",
				children: ["Baca Selengkapnya ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconArrowRight, { size: 15 })]
			})
		]
	});
}
//#endregion
export { AnalisisCard as t };
