import { x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { b as cn } from "./router-BoayDiKZ.mjs";
import { t as PageHero } from "./page-hero-DPk741Nb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/kalender-ekonomi-DMf9sJYx.js
var import_jsx_runtime = require_jsx_runtime();
var CALENDAR_EVENTS = [
	{
		time: "19:30 WIB",
		country: "US",
		event: "Data Inflasi (CPI) YoY",
		impact: "high",
		forecast: "3.2%",
		previous: "3.1%"
	},
	{
		time: "19:30 WIB",
		country: "US",
		event: "Initial Jobless Claims",
		impact: "medium",
		forecast: "215K",
		previous: "220K"
	},
	{
		time: "15:00 WIB",
		country: "EU",
		event: "Suku Bunga ECB",
		impact: "high",
		forecast: "4.00%",
		previous: "4.00%"
	},
	{
		time: "09:30 WIB",
		country: "CN",
		event: "PMI Manufaktur",
		impact: "medium",
		forecast: "50.2",
		previous: "49.8"
	},
	{
		time: "20:00 WIB",
		country: "US",
		event: "Pidato Ketua The Fed",
		impact: "high",
		forecast: "—",
		previous: "—"
	},
	{
		time: "14:00 WIB",
		country: "ID",
		event: "Keputusan Suku Bunga BI",
		impact: "low",
		forecast: "6.00%",
		previous: "6.00%"
	}
];
var IMPACT_LABEL = {
	high: "Tinggi",
	medium: "Sedang",
	low: "Rendah"
};
function KalenderPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
		eyebrow: "Kalender Ekonomi",
		title: "Jadwal Rilis Data Ekonomi",
		description: "Pantau jadwal rilis data ekonomi penting yang berpotensi menggerakkan pasar forex, emas, dan kripto."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "py-16 max-md:py-11",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container-site",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto rounded-[14px] border border-line",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-[640px] border-collapse",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: [
						"Waktu",
						"Negara",
						"Event",
						"Dampak",
						"Forecast",
						"Previous"
					].map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "bg-bg-alt px-[18px] py-3.5 text-left text-[12.5px] font-bold tracking-wide text-muted uppercase",
						children: h
					}, h)) }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: CALENDAR_EVENTS.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t border-line",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-[18px] py-3.5 text-sm",
								children: e.time
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-[18px] py-3.5 text-sm",
								children: e.country
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-[18px] py-3.5 text-sm",
								children: e.event
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-[18px] py-3.5 text-sm",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "inline-flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: cn("size-2 rounded-full", e.impact === "high" && "bg-accent-red", e.impact === "medium" && "bg-accent-orange", e.impact === "low" && "bg-accent-green"),
										"aria-hidden": "true"
									}), IMPACT_LABEL[e.impact]]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-[18px] py-3.5 text-sm tabular-nums",
								children: e.forecast
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-[18px] py-3.5 text-sm tabular-nums",
								children: e.previous
							})
						]
					}, `${e.country}-${e.event}`)) })]
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-[13.5px] text-subtle",
				children: "Data di atas adalah contoh tampilan. Untuk data real-time, kalender ini bisa dihubungkan ke API kalender ekonomi."
			})]
		})
	})] });
}
//#endregion
export { KalenderPage as component };
