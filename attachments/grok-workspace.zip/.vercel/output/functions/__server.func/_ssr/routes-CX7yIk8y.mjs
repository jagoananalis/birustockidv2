import { x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as NEWS, a as CandlestickPattern, c as IconDocument, f as IconTikTok, g as BrandLockup, l as IconGraduation, m as NewsThumb, o as IconArrowRight, p as IconTrendUp, s as IconCalendar, x as ANALISIS } from "./router-BoayDiKZ.mjs";
import { t as AnalisisCard } from "./analisis-card-Dq3RMY7L.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CX7yIk8y.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const topAnalisis = ANALISIS.slice(0, 3);
	const topNews = NEWS.slice(0, 3);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "overflow-hidden bg-linear-to-b from-bg-alt to-bg",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-site grid items-center gap-10 py-16 max-md:py-10 md:grid-cols-[1.05fr_0.95fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "eyebrow",
						children: "Analisis. Edukasi. Insight."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "mt-3.5 mb-5 text-5xl leading-[1.12] font-extrabold tracking-tight text-ink max-md:text-4xl",
						children: [
							"Insight Pasar,",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							"Keputusan Lebih Baik."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-8 max-w-md text-base text-muted",
						children: "Birustock ID menyediakan analisis teknikal, berita pasar, dan edukasi trading untuk membantu kamu memahami pergerakan Crypto, Forex, dan Gold."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-3.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/analisis",
							className: "btn btn-primary",
							children: "Lihat Analisis Terbaru"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: "https://www.tiktok.com/@birustock.id",
							target: "_blank",
							rel: "noopener noreferrer",
							className: "btn btn-outline",
							children: ["Ikuti TikTok Kami ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconTikTok, { size: 16 })]
						})]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex min-h-80 items-center justify-center overflow-hidden rounded-lg bg-linear-to-br from-bg-alt to-line max-md:order-first max-md:min-h-56",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "pointer-events-none absolute inset-0 flex items-center opacity-55",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CandlestickPattern, {})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "relative z-1",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrandLockup, { size: "lg" })
					})]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "py-16 max-md:py-11",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-site grid items-start gap-10 lg:grid-cols-[1fr_340px]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-6 flex items-baseline justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-2xl font-extrabold tracking-tight",
						children: "Analisis Terbaru"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/analisis",
						className: "link-arrow",
						children: ["Lihat Semua ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconArrowRight, { size: 15 })]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-5 md:grid-cols-3",
					children: topAnalisis.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnalisisCard, { item }, item.slug))
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "rounded-md border border-line p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mb-5 text-xl font-extrabold",
							children: "Berita Terbaru"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-col gap-4",
							children: topNews.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/news/$slug",
								params: { slug: item.slug },
								className: "flex gap-3.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "size-16 shrink-0 overflow-hidden rounded-sm",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NewsThumb, { type: item.thumb })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mb-1 text-xs text-subtle",
									children: item.date
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "text-sm leading-snug font-bold",
									children: item.title
								})] })]
							}, item.slug))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/news",
							className: "link-arrow mt-5",
							children: ["Lihat Semua Berita ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconArrowRight, { size: 15 })]
						})
					]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-bg-alt py-11",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-site grid gap-8 sm:grid-cols-2 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Feature, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconTrendUp, {}),
						title: "Analisis Terstruktur",
						desc: "Analisis teknikal harian dan mingguan dengan level penting."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Feature, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconDocument, {}),
						title: "News Update",
						desc: "Informasi pasar terkini dan berdampak langsung ke market."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Feature, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconGraduation, {}),
						title: "Edukasi Trading",
						desc: "Belajar trading dari dasar hingga strategi lanjutan."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Feature, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconCalendar, {}),
						title: "Kalender Ekonomi",
						desc: "Jadwal rilis data ekonomi penting untuk trader."
					})
				]
			})
		})
	] });
}
function Feature({ icon, title, desc }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-start gap-3.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "icon-tile",
			children: icon
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
			className: "mb-1.5 text-[15px] font-bold",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: desc
		})] })]
	});
}
//#endregion
export { Home as component };
