import { i as __toESM } from "../_runtime.mjs";
import { V as require_react, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { S as getAnalisisPairs, x as ANALISIS } from "./router-BoayDiKZ.mjs";
import { t as AnalisisCard } from "./analisis-card-Dq3RMY7L.mjs";
import { t as FilterChips } from "./filter-chips-CNmqGoHs.mjs";
import { t as PageHero } from "./page-hero-DPk741Nb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/analisis-CtZ7F2rW.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AnalisisPage() {
	const pairs = (0, import_react.useMemo)(() => ["Semua", ...getAnalisisPairs()], []);
	const [filter, setFilter] = (0, import_react.useState)("Semua");
	const items = filter === "Semua" ? ANALISIS : ANALISIS.filter((a) => a.pair === filter);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
		eyebrow: "Analisis Teknikal",
		title: "Analisis Terbaru",
		description: "Kumpulan analisis teknikal harian untuk pasangan Forex, Emas (XAUUSD), dan Kripto favoritmu."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "py-16 max-md:py-11",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container-site",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChips, {
				options: pairs,
				value: filter,
				onChange: setFilter,
				label: "Filter pasangan"
			}), items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "py-6 text-sm text-subtle",
				children: "Tidak ada analisis untuk pasangan ini."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-[22px] sm:grid-cols-2 lg:grid-cols-3",
				children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnalisisCard, { item }, item.slug))
			})]
		})
	})] });
}
//#endregion
export { AnalisisPage as component };
