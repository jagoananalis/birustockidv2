import { x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as IconArrowRight, y as EDUKASI } from "./router-BoayDiKZ.mjs";
import { t as PageHero } from "./page-hero-DPk741Nb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/edukasi-BgJui_QT.js
var import_jsx_runtime = require_jsx_runtime();
function EdukasiPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
		eyebrow: "Edukasi Trading",
		title: "Belajar dari Dasar hingga Lanjutan",
		description: "Materi edukasi seputar forex, emas, dan kripto — disusun bertahap agar mudah diikuti pemula maupun trader berpengalaman."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "py-16 max-md:py-11",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "container-site",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-[22px] sm:grid-cols-2 lg:grid-cols-3",
				children: EDUKASI.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/edukasi/$slug",
					params: { slug: item.slug },
					className: "edu-card",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mb-2 text-xs font-bold tracking-wide text-primary uppercase",
							children: item.level
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mb-2 text-[17px] font-bold",
							children: item.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: item.desc
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "link-arrow mt-3",
							children: ["Baca Materi ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconArrowRight, { size: 15 })]
						})
					]
				}, item.slug))
			})
		})
	})] });
}
//#endregion
export { EdukasiPage as component };
