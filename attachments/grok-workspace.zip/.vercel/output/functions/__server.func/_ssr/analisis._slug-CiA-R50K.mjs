import { x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { b as cn, i as Route$2, o as IconArrowRight } from "./router-BoayDiKZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/analisis._slug-CiA-R50K.js
var import_jsx_runtime = require_jsx_runtime();
var ACCENT = {
	blue: "",
	orange: "badge-orange",
	green: "badge-green",
	red: "badge-red"
};
function AnalisisDetail() {
	const item = Route$2.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "py-16 max-md:py-11",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "container-site",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "mx-auto max-w-[760px]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mb-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/analisis",
							className: "link-arrow",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "inline-block rotate-180",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconArrowRight, { size: 15 })
							}), "Kembali ke Analisis"]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-4 flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("badge", ACCENT[item.accent]),
							children: item.pair
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[13px] text-subtle",
							children: item.date
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mb-5 text-[30px] leading-snug font-extrabold tracking-tight",
						children: item.title
					}),
					item.body.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-4.5 text-base leading-relaxed text-muted",
						children: p
					}, p)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-8 rounded-[8px] bg-bg-alt px-4.5 py-4 text-[13.5px] text-muted",
						children: "Analisis ini bersifat edukasi dan bukan merupakan ajakan atau rekomendasi untuk membeli/menjual instrumen tertentu. Selalu gunakan manajemen risiko pribadi."
					})
				]
			})
		})
	});
}
//#endregion
export { AnalisisDetail as component };
