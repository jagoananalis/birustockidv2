//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-MyAeS_w7.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/analisis",
			"/edukasi",
			"/kalender-ekonomi",
			"/kontak",
			"/news",
			"/profil"
		],
		preloads: [
			"/assets/index-CoOxqC_T.js",
			"/assets/jsx-runtime-BkSabwWG.js",
			"/assets/link-BUtwDr6S.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CoOxqC_T.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BTSWpmyY.js", "/assets/analisis-card-BTiDXppg.js"]
	},
	"/analisis": {
		filePath: "/workspace/src/routes/analisis.tsx",
		children: ["/analisis/$slug"],
		preloads: [
			"/assets/analisis-CHxNyOuP.js",
			"/assets/analisis-card-BTiDXppg.js",
			"/assets/filter-chips-vPFb4-LB.js",
			"/assets/page-hero-BA3bJGUa.js"
		]
	},
	"/edukasi": {
		filePath: "/workspace/src/routes/edukasi.tsx",
		children: ["/edukasi/$slug"],
		preloads: ["/assets/edukasi-7Ia4Mdxc.js", "/assets/page-hero-BA3bJGUa.js"]
	},
	"/kalender-ekonomi": {
		filePath: "/workspace/src/routes/kalender-ekonomi.tsx",
		children: void 0,
		preloads: ["/assets/kalender-ekonomi-cJOuViqE.js", "/assets/page-hero-BA3bJGUa.js"]
	},
	"/kontak": {
		filePath: "/workspace/src/routes/kontak.tsx",
		children: void 0,
		preloads: ["/assets/kontak-D-D18Z2d.js", "/assets/page-hero-BA3bJGUa.js"]
	},
	"/news": {
		filePath: "/workspace/src/routes/news.tsx",
		children: ["/news/$slug"],
		preloads: [
			"/assets/news-CVYPLZlS.js",
			"/assets/filter-chips-vPFb4-LB.js",
			"/assets/page-hero-BA3bJGUa.js"
		]
	},
	"/profil": {
		filePath: "/workspace/src/routes/profil.tsx",
		children: void 0,
		preloads: ["/assets/profil-D0x8EOyL.js", "/assets/page-hero-BA3bJGUa.js"]
	},
	"/analisis/$slug": {
		filePath: "/workspace/src/routes/analisis.$slug.tsx",
		children: void 0,
		preloads: ["/assets/analisis._slug-BOdfHc6Z.js"]
	},
	"/edukasi/$slug": {
		filePath: "/workspace/src/routes/edukasi.$slug.tsx",
		children: void 0,
		preloads: ["/assets/edukasi._slug-BDMFNZkS.js"]
	},
	"/news/$slug": {
		filePath: "/workspace/src/routes/news.$slug.tsx",
		children: void 0,
		preloads: ["/assets/news._slug-ClO4jNcY.js"]
	}
} });
//#endregion
export { tsrStartManifest };
