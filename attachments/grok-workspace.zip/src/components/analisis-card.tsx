import { Link } from "@tanstack/react-router";
import { IconArrowRight, PairIcon } from "@/components/icons";
import type { AnalisisItem } from "@/data/analisis";
import { cn } from "@/lib/utils";

const ACCENT = {
  blue: "",
  orange: "badge-orange",
  green: "badge-green",
  red: "badge-red",
} as const;

const TILE = {
  blue: "",
  orange: "icon-tile-orange",
  green: "icon-tile-green",
  red: "icon-tile-red",
} as const;

export function AnalisisCard({ item }: { item: AnalisisItem }) {
  return (
    <article className="card">
      <div className="flex items-center justify-between">
        <span className={cn("badge", ACCENT[item.accent])}>{item.pair}</span>
        <span className="text-[13px] text-subtle">{item.date}</span>
      </div>
      <div className="flex items-start justify-between gap-3">
        <div>
          <h3 className="text-[17px] leading-snug font-bold text-ink">{item.title}</h3>
          <p className="mt-1 text-sm text-muted">{item.excerpt}</p>
        </div>
        <div className={cn("icon-tile", TILE[item.accent])}>
          <PairIcon id={item.icon} />
        </div>
      </div>
      <Link to="/analisis/$slug" params={{ slug: item.slug }} className="link-arrow">
        Baca Selengkapnya <IconArrowRight size={15} />
      </Link>
    </article>
  );
}
