export function PageHero({
  eyebrow,
  title,
  description,
}: {
  eyebrow: string;
  title: string;
  description: string;
}) {
  return (
    <section className="border-b border-line bg-bg-alt py-12">
      <div className="container-site">
        <span className="eyebrow">{eyebrow}</span>
        <h1 className="mt-2 mb-2.5 text-[32px] font-extrabold tracking-tight text-ink">{title}</h1>
        <p className="max-w-[620px] text-muted">{description}</p>
      </div>
    </section>
  );
}
