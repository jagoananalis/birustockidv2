export type NewsItem = {
  slug: string;
  date: string;
  category: string;
  thumb: "capitol" | "gold" | "bitcoin";
  title: string;
  excerpt: string;
  body: string[];
};

export const NEWS: NewsItem[] = [
  {
    slug: "fed-pertahankan-suku-bunga",
    date: "22 Mei 2024",
    category: "Ekonomi Global",
    thumb: "capitol",
    title: "The Fed Pertahankan Suku Bunga, Pasar Menunggu Data Inflasi",
    excerpt:
      "Bank sentral Amerika Serikat memutuskan mempertahankan suku bunga acuan, sembari pasar menanti rilis data inflasi berikutnya sebagai penentu arah kebijakan.",
    body: [
      "The Federal Reserve memutuskan untuk mempertahankan suku bunga acuan pada level saat ini, sesuai dengan ekspektasi mayoritas pelaku pasar.",
      "Dalam pernyataannya, bank sentral menekankan bahwa keputusan ke depan akan sangat bergantung pada perkembangan data inflasi dan tenaga kerja.",
      "Pasar keuangan global merespons dengan volatilitas terbatas, sembari menunggu rilis data inflasi berikutnya sebagai indikator arah kebijakan suku bunga selanjutnya.",
    ],
  },
  {
    slug: "emas-menguat-ketidakpastian-global",
    date: "22 Mei 2024",
    category: "Emas",
    thumb: "gold",
    title: "Emas Menguat di Tengah Ketidakpastian Global",
    excerpt:
      "Harga emas mencatat penguatan seiring meningkatnya permintaan aset safe haven di tengah ketidakpastian ekonomi dan geopolitik global.",
    body: [
      "Harga emas dunia bergerak menguat, didorong oleh meningkatnya minat investor terhadap aset safe haven.",
      "Ketidakpastian geopolitik serta ekspektasi kebijakan moneter yang beragam turut menjadi faktor pendukung penguatan harga emas.",
      "Analis menilai tren ini berpotensi berlanjut selama sentimen ketidakpastian global masih membayangi pasar.",
    ],
  },
  {
    slug: "etf-bitcoin-inflow-tertinggi",
    date: "21 Mei 2024",
    category: "Kripto",
    thumb: "bitcoin",
    title: "ETF Bitcoin Spot Catat Inflow Tertinggi dalam 2 Minggu",
    excerpt:
      "Produk ETF Bitcoin spot mencatatkan arus masuk dana tertinggi dalam dua minggu terakhir, menandakan minat institusi yang kembali meningkat.",
    body: [
      "Sejumlah produk ETF Bitcoin spot mencatatkan arus masuk dana (inflow) tertinggi dalam dua minggu terakhir.",
      "Peningkatan ini mengindikasikan minat investor institusi terhadap aset kripto kembali menguat.",
      "Para pelaku pasar akan memantau apakah tren inflow ini dapat berlanjut dan memberi dampak positif terhadap harga Bitcoin secara keseluruhan.",
    ],
  },
  {
    slug: "data-tenaga-kerja-as",
    date: "19 Mei 2024",
    category: "Ekonomi Global",
    thumb: "capitol",
    title: "Data Tenaga Kerja AS Jadi Sorotan Pelaku Pasar Minggu Ini",
    excerpt:
      "Rilis data tenaga kerja Amerika Serikat pekan ini diperkirakan akan menjadi katalis penting bagi pergerakan dolar dan pasar global.",
    body: [
      "Pelaku pasar tengah menantikan rilis data tenaga kerja Amerika Serikat yang dijadwalkan pekan ini.",
      "Data ini berpotensi memberikan gambaran lebih jelas mengenai kondisi ekonomi AS dan arah kebijakan moneter ke depan.",
      "Pergerakan dolar AS dan pasar global diperkirakan akan cukup sensitif terhadap hasil rilis data tersebut.",
    ],
  },
];

export function getNews(slug: string) {
  return NEWS.find((item) => item.slug === slug);
}

export function getNewsCategories() {
  return [...new Set(NEWS.map((item) => item.category))];
}
