import { createFileRoute, Link } from "@tanstack/react-router";
import { IconArrowRight } from "@/components/icons";
import { PageHero } from "@/components/page-hero";
import { EDUKASI } from "@/data/edukasi";

export const Route = createFileRoute("/edukasi")({
  component: EdukasiPage,
  head: () => ({
    meta: [{ title: "Edukasi Trading | Birustock Indonesia" }],
  }),
});

function EdukasiPage() {
  return (
    <>
      <PageHero
        eyebrow="Edukasi Trading"
        title="Belajar dari Dasar hingga Lanjutan"
        description="Materi edukasi seputar forex, emas, dan kripto — disusun bertahap agar mudah diikuti pemula maupun trader berpengalaman."
      />
      <section className="py-16 max-md:py-11">
        <div className="container-site">
          <div className="grid gap-[22px] sm:grid-cols-2 lg:grid-cols-3">
            {EDUKASI.map((item) => (
              <Link key={item.slug} to="/edukasi/$slug" params={{ slug: item.slug }} className="edu-card">
                <div className="mb-2 text-xs font-bold tracking-wide text-primary uppercase">{item.level}</div>
                <h3 className="mb-2 text-[17px] font-bold">{item.title}</h3>
                <p className="text-sm text-muted">{item.desc}</p>
                <span className="link-arrow mt-3">
                  Baca Materi <IconArrowRight size={15} />
                </span>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
