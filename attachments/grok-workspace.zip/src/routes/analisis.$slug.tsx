import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { IconArrowRight } from "@/components/icons";
import { getAnalisis } from "@/data/analisis";
import { cn } from "@/lib/utils";

const ACCENT = {
  blue: "",
  orange: "badge-orange",
  green: "badge-green",
  red: "badge-red",
} as const;

export const Route = createFileRoute("/analisis/$slug")({
  loader: ({ params }) => {
    const item = getAnalisis(params.slug);
    if (!item) throw notFound();
    return item;
  },
  component: AnalisisDetail,
  head: ({ loaderData }) => ({
    meta: [
      { title: `${loaderData?.title ?? "Analisis"} | Birustock Indonesia` },
      { name: "description", content: loaderData?.excerpt ?? "" },
    ],
  }),
});

function AnalisisDetail() {
  const item = Route.useLoaderData();

  return (
    <section className="py-16 max-md:py-11">
      <div className="container-site">
        <article className="mx-auto max-w-[760px]">
          <div className="mb-6">
            <Link to="/analisis" className="link-arrow">
              <span className="inline-block rotate-180">
                <IconArrowRight size={15} />
              </span>
              Kembali ke Analisis
            </Link>
          </div>
          <div className="mb-4 flex items-center gap-3">
            <span className={cn("badge", ACCENT[item.accent])}>{item.pair}</span>
            <span className="text-[13px] text-subtle">{item.date}</span>
          </div>
          <h1 className="mb-5 text-[30px] leading-snug font-extrabold tracking-tight">{item.title}</h1>
          {item.body.map((p) => (
            <p key={p} className="mb-4.5 text-base leading-relaxed text-muted">
              {p}
            </p>
          ))}
          <div className="mt-8 rounded-[8px] bg-bg-alt px-4.5 py-4 text-[13.5px] text-muted">
            Analisis ini bersifat edukasi dan bukan merupakan ajakan atau rekomendasi untuk
            membeli/menjual instrumen tertentu. Selalu gunakan manajemen risiko pribadi.
          </div>
        </article>
      </div>
    </section>
  );
}
