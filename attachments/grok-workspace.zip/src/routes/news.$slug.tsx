import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { IconArrowRight } from "@/components/icons";
import { getNews } from "@/data/news";

export const Route = createFileRoute("/news/$slug")({
  loader: ({ params }) => {
    const item = getNews(params.slug);
    if (!item) throw notFound();
    return item;
  },
  component: NewsDetail,
  head: ({ loaderData }) => ({
    meta: [
      { title: `${loaderData?.title ?? "News"} | Birustock Indonesia` },
      { name: "description", content: loaderData?.excerpt ?? "" },
    ],
  }),
});

function NewsDetail() {
  const item = Route.useLoaderData();

  return (
    <section className="py-16 max-md:py-11">
      <div className="container-site">
        <article className="mx-auto max-w-[760px]">
          <div className="mb-6">
            <Link to="/news" className="link-arrow">
              <span className="inline-block rotate-180">
                <IconArrowRight size={15} />
              </span>
              Kembali ke News
            </Link>
          </div>
          <div className="mb-4 flex items-center gap-3">
            <span className="badge">{item.category}</span>
            <span className="text-[13px] text-subtle">{item.date}</span>
          </div>
          <h1 className="mb-5 text-[30px] leading-snug font-extrabold tracking-tight">{item.title}</h1>
          {item.body.map((p) => (
            <p key={p} className="mb-4.5 text-base leading-relaxed text-muted">
              {p}
            </p>
          ))}
        </article>
      </div>
    </section>
  );
}
