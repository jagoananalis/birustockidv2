import { createFileRoute } from "@tanstack/react-router";
import { PageHero } from "@/components/page-hero";
import { CALENDAR_EVENTS, IMPACT_LABEL } from "@/data/kalender";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/kalender-ekonomi")({
  component: KalenderPage,
  head: () => ({
    meta: [{ title: "Kalender Ekonomi | Birustock Indonesia" }],
  }),
});

function KalenderPage() {
  return (
    <>
      <PageHero
        eyebrow="Kalender Ekonomi"
        title="Jadwal Rilis Data Ekonomi"
        description="Pantau jadwal rilis data ekonomi penting yang berpotensi menggerakkan pasar forex, emas, dan kripto."
      />
      <section className="py-16 max-md:py-11">
        <div className="container-site">
          <div className="overflow-x-auto rounded-[14px] border border-line">
            <table className="w-full min-w-[640px] border-collapse">
              <thead>
                <tr>
                  {["Waktu", "Negara", "Event", "Dampak", "Forecast", "Previous"].map((h) => (
                    <th
                      key={h}
                      className="bg-bg-alt px-[18px] py-3.5 text-left text-[12.5px] font-bold tracking-wide text-muted uppercase"
                    >
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {CALENDAR_EVENTS.map((e) => (
                  <tr key={`${e.country}-${e.event}`} className="border-t border-line">
                    <td className="px-[18px] py-3.5 text-sm">{e.time}</td>
                    <td className="px-[18px] py-3.5 text-sm">{e.country}</td>
                    <td className="px-[18px] py-3.5 text-sm">{e.event}</td>
                    <td className="px-[18px] py-3.5 text-sm">
                      <span className="inline-flex items-center gap-1.5">
                        <span
                          className={cn(
                            "size-2 rounded-full",
                            e.impact === "high" && "bg-accent-red",
                            e.impact === "medium" && "bg-accent-orange",
                            e.impact === "low" && "bg-accent-green",
                          )}
                          aria-hidden="true"
                        />
                        {IMPACT_LABEL[e.impact]}
                      </span>
                    </td>
                    <td className="px-[18px] py-3.5 text-sm tabular-nums">{e.forecast}</td>
                    <td className="px-[18px] py-3.5 text-sm tabular-nums">{e.previous}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="mt-4 text-[13.5px] text-subtle">
            Data di atas adalah contoh tampilan. Untuk data real-time, kalender ini bisa dihubungkan
            ke API kalender ekonomi.
          </p>
        </div>
      </section>
    </>
  );
}
